
public class Node 
{
	int data;
	int timeStamp;
	Node(int data, int timeStamp)
	{
		this.data = data;
		this.timeStamp = timeStamp;
	}
}
