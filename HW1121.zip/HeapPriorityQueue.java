import java.util.*;
public class HeapPriorityQueue
{
	int age=-1;
	int maxAge = 0;
	Node maxAgeNode;
	protected ArrayList<Node> heap = new ArrayList<>();
	
	public HeapPriorityQueue()
	{
		
	}
	protected int parent(int j)
	{
		return (j-1)/2;
	}
	protected int left(int j)
	{
		return 2*j +1;
	}
	protected int right(int j)
	{
		return 2*j +2;
	}
	protected boolean hasLeft(int j)
	{
		return left(j) < heap.size();
	}
	protected boolean hasRight(int j)
	{
		return right(j) < heap.size();
	}
	protected void swap(int i, int j)
	{
		Node temp = heap.get(i);
		heap.set(i, heap.get(j));
		heap.set(j, temp);
	}
	protected void upheap(int j)
	{
		while(j > 0)
		{
			int p = parent(j);
			if(heap.get(j).data>=heap.get(p).data)
			{
				break;
			}
			swap(j,p);
			j = p;
		}
	}
	protected void downheap(int j)
	{
		while(hasLeft(j))
		{
			int leftIndex = left(j);
			int smallChildIndex = leftIndex;
			if(hasRight(j))
			{
				int rightIndex = right(j);
				if(heap.get(leftIndex).data >= heap.get(rightIndex).data)
				{
					smallChildIndex = rightIndex;
				}
			}
			if(heap.get(smallChildIndex).data >= heap.get(j).data)
			{
				break;
			}
			swap(j, smallChildIndex);
			j = smallChildIndex;
		}
	}
	public int size()
	{
		return heap.size();
	}
	public Node min()
	{
		if(heap.isEmpty())
		{
			return null;
		}
		return heap.get(0);
	}
	public Node insert(int data)
	{
		age++;
		Node newest = new Node(data, age);
		heap.add(newest);
		upheap(heap.size()-1);
		return newest;
	}
	public Node delete()
	{
		age++;
		if (heap.isEmpty())
		{
			return null;
		}
		Node answer = heap.get(0);
		computMaxAge(answer);
		swap(0,heap.size()-1);
		heap.remove(heap.size()-1);
		downheap(0);
		return answer;
	}
	public void computMaxAge(Node n)
	{
		int nodeAge = this.age - n.timeStamp;
		if (nodeAge > this.maxAge)
		{
			maxAge = nodeAge;
			maxAgeNode = n;
		}
	}
}
