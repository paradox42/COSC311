
public class HW1121 
{
	public static void main(String[] args)
	{
		HeapPriorityQueue queue = new HeapPriorityQueue();
		queue.insert(1);
		queue.insert(7);
		queue.insert(3);
		queue.insert(4);
		queue.insert(5);
		queue.insert(6);
		queue.insert(1);
		queue.insert(2);
		queue.insert(3);
		for(int i = 0; i < queue.size(); i++)
		{
			System.out.println(queue.heap.get(i).data + "(" + queue.heap.get(i).timeStamp + ")");
		}
		while(!queue.heap.isEmpty())
		{
			Node poped = queue.delete();
			System.out.println("deleted: " + poped.data + "(" + poped.timeStamp + ")");
			System.out.println("The oldest element is age = "+ queue.maxAge + ", with data = " + queue.maxAgeNode.data);
		}
	}
}
