/*
 * Name: Jiansong he
 * URL : https://github.com/paradox42/COSC311/blob/master/HW1014.zip
 * COSC: 311
 * HW 10/12
 * FALL 2016
 */
public class HW1014 
{
	static int[] table = new int[1000];
	public static void main(String[] args)
	{
		System.out.println(fibonacci(6));
	}
	
	public static int fibonacci(int k)
	{
		if (table[k] != 0)
		{
			return table[k];
		}
		if (k == 0 || k == 1)
		{
			return 1;
		}
		else
		{
			table[k] = fibonacci(k-1) + fibonacci(k-2);
			return fibonacci(k-1) + fibonacci(k-2);
		}
	}
}
