import java.util.Arrays;


public class HW1205 
{
	static int counter;
	public static void main(String[] args)
	{
		counter =0;
		String[] array = {"ikeji", "bahorski", "chaudhuri","evett",
				"haynes","maniccam", "moore","narayanan",
				"panja", "poh","sverdlik","tehranipour",
				"zeiger","zhang","cowan","francis","mansour"};
		mergeSort(array);
		for(String s: array)
		{
			System.out.println(s);
		}
		System.out.println("\nThe method mergeSort has been invoked for "+counter+" times");
	}
	
	public static void mergeSort(String[] array)
	{
		counter++;
		int n = array.length;
		if(n<2)
		{
			return;
		}
		int mid = n/2;
		String[] part1 = Arrays.copyOfRange(array,0,mid);
		String[] part2 = Arrays.copyOfRange(array,mid,n);
		mergeSort(part1);
		mergeSort(part2);
		merge(part1,part2, array);
	}
	
	public static void merge(String[] arr1, String[] arr2, String[]target)       //concatenate and order two inputed list, return them as one
	{
		int i=0, j=0;
		while(i+j < target.length)
		{
			if(j==arr2.length || (i<arr1.length && arr1[i].compareTo(arr2[j]) < 0))    //
			{
				target[i+j] = arr1[i++];
			}
			else													//j<arr2.length or i==arr1.length
			{
				target[i+j] = arr2[j++];
			}
		}
	}
}
