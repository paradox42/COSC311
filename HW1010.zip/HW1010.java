public class HW1010 
{
	public static void main(String[] args)
	{
		Stack s1 = new Stack(100);
		
		int[] array = {10,7,2,9,0,5,15};
		for(int i = 0; i < array.length; i++)
		{
			s1.push(array[i]);
		}
		
		System.out.println(s1.max());
		while(!s1.isEmpty())
		{
			System.out.println(s1.pop());
		}
	}

}
