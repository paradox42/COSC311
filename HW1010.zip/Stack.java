
public class Stack
{
	public static final int CAPACITY = 1000;
	private int[] data;
	private int t = -1;
	
	public Stack(){this(CAPACITY);}

	public Stack(int capacity) 
	{
		data = new int[capacity];
	}
	
	public int size()
	{
		return(t+1);
	}
	
	public boolean isEmpty()
	{
		return (t == -1);
	}
	
	public void push(int e) throws IllegalStateException
	{
		if (size() == data.length) 
		{
			throw new IllegalStateException("Stack is full");
		}
		else
		{
			t++;
			data[t] = e;
		}
	}
	
	@SuppressWarnings("null")
	public int top()
	{
		if (isEmpty())
		{
			return (Integer) null;
		}
		else
		{
			return data[t];
		}
	}
	
	@SuppressWarnings("null")
	public int pop()
	{
		if(isEmpty())
		{
			return (Integer) null;
		}
		else
		{
			int answer = data[t];
			data[t] = 0;
			t--;
			return (int) answer;
		}
	}
	
	public int max()
	{
		int current = this.top();
		Stack pushBack = new Stack(data.length);
		while(!isEmpty())
		{
			if (current < this.top())
			{
				current = this.top();
				pushBack.push(this.pop());
			}
			else
			{
				pushBack.push(this.pop());
			}
		}
		while(!pushBack.isEmpty())
		{
			this.push(pushBack.pop());
		}
		return current;
	}

}
