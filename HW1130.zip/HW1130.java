/*
 * Jiansong He
 * https://github.com/paradox42/COSC311
 * COSC 311
 * HW 1130
 * FALL 2016
 */
public class HW1130
{
	public static void main(String[] args)
	{
		String[] targets = {"ikeji", "bahorski", "chaudhuri","evett",
							"haynes","maniccam", "moore","narayanan",
							"panja", "poh","sverdlik","tehranipour",
							"zeiger","zhang","cowan","francis","mansour"};
		HashTable ht = new HashTable();

		for(String s: targets)
		{
			ht.put(s);
		}
		//ht.put("someother");
		System.out.println("Insertion of hash table done, printing the hash table: ");
		ht.print();
		System.out.println("done");
	}
}
