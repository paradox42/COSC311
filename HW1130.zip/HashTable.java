import java.util.Arrays;


public class HashTable 
{
	String[] values;
			/*{"ikeji", "bahorski", "chaudhuri","evett",
			"haynes","maniccam", "moore","narayanan"};*/
			/*"panja", "poh","sverdlik","tehranipour",
			"zeiger","zhang","cowan","francis","mansour"};*/
	int size = 8;
	int count = 0;
	
	public HashTable()
	{
		this.values = new String[size];
		//this.values = {"ikeji", "bahorski", "chaudhuri","evett","haynes","maniccam", "moore","narayanan"}
	}
	
	public void put(String value)
	{
		count++;
		if (isOverload())
		{
			resize();
		}
		values[setIndex(value)] = value;
	}
	
	private boolean isOverload()
	{
		float load = ((float)count)/size;
		return load>=0.75;
	}
	
	private void resize()
	{
		print();
		System.out.println("Hashtable overloaded, start rehash");
		this.values = Arrays.copyOf(values, size*2);
		this.size = size*2;
		rehash();
	}
	
	private int setIndex(String value)
	{
		int index = (value.hashCode()&0x7FFFFFFF)%size;
		while(values[index] != null)
		{
			index = (index+1)%this.size;
		}
		return index;
	}
	
	private void rehash()
	{
		for(int i=0;i<size; i++)
		{
			if(values[i] != null)
			{
				int index = setIndex(values[i]);
				String temp = values[i];
				values[i] = null;
				values[index] = temp;
			}
		}
	}
	
	public void print()
	{
		for(int i=0;i<this.size;i++)
		{
			System.out.printf("%s(%d) ",values[i],i);
		}
		System.out.println();
	}
}
