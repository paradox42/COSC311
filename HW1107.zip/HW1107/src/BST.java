
public class BST 
{
	
	Node root;
	
	public BST()
	{
		root = null;
	}
	public String toString()
	{
		if (root == null) return "null";
		String s = "";
		s += inorder(root);
		return s;
	}
	
	public static String inorder(Node n)
	{
		if (n==null) return "";
		
		String s = "";
		s += "." + inorder(n.left) +
				"." + n.data +
				"." + inorder(n.right);
		return s;
	}
	
	public static Node insert( int x, Node n) 
	{
		if (n == null) 
		{
			return (new Node(x));
		}
		else if (x <= n.data) 
		{
			n.left = insert(x, n.left);
			return n;
		}
		else 
		{								// x > n.data
			n.right = insert(x, n.right);
			return n;
		}
	}

	public static Node find(int x, Node n) 
	{
		if (n == null)
			return null;

		if (x == n.data)
			return n;

		else if (x < n.data)
			return find(x, n.left);

		else
			// x > n.data
			return find(x, n.right);
	}

	public static Node findMin(Node n) 
	{
		if (n == null) // empty tree
			return null;

		if (n.left == null)
			return n;

		return findMin(n.left);
	}
	
	public static Node delete(int x, Node n)
	{
		if (n == null) // nothing to do
			return n;

		if (x == n.data) 
		{ // found first node containing x

			if (n.left == null && n.right == null) // n is a leaf
				return null; // let garbage collector remove n

			else if (n.left == null) 
			{ // has right child only
				n.right = delete(x, n.right);
				return n;
			}

			else if (n.right == null) 
			{ // has left child only
				n.left = delete(x, n.left);
				return n;
			}

			else
			{ // has two children
				Node tempNode = findMin(n.right);
				n.right = delete(tempNode.data, n.right);
				n.data = tempNode.data;
				return n;
			}
		} // end of found node containing x

		if (x < n.data) 
		{
			n.left = delete(x, n.left);
			return n;
		}
		else 
		{ // x > n.data
			n.right = delete(x, n.right);
			return n;
		}
	}
	
	private static int max(int a, int b)
	{
		if (a>b)
			return a;
		else 
			return b;
	}
	
	public static Integer height(Node n)  //compute the height of the node
	{
		if(n == null)
			return -1;
		else if(n.left == null && n.right == null)
			return 0;
		else
		{
			return 1 + max(height(n.left), height(n.right));
		}
	}
	
	public static Integer balance(Node n)
	{
		if(n == null || (n.left == null && n.right == null))
			return 0;
		else
		{
			return height(n.left) - height(n.right);
		}
	}
}	