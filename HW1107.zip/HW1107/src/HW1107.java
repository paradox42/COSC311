
public class HW1107 
{
	public static void main(String[] args)
	{
		BST top = new BST();
		int[] data = {10,5,15,3,13,17,18,22,21};
		
		for(int i = 0; i < data.length; i++)
		{
			top.root = BST.insert(data[i], top.root);
		}
		int h = BST.height(top.root);
		
		System.out.println(BST.inorder(top.root));
		System.out.println(BST.balance(top.root));
	}
}
