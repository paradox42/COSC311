public class Node
{

	public Integer data;
	public Node left, right;

	public Node() 
	{
		this.data = null;
		this.left = null;
		this.right = null;
	}

	public Node(Integer x) 
	{
		this.data = x;
		this.left = null;
		this.right = null;
	}
}
