public class Stack
{
	public static final int CAPACITY = 1000;
	private char[] data;
	private int t = -1;
	
	public Stack(){this(CAPACITY);}

	public Stack(int capacity) 
	{
		data = new char[capacity];
	}
	
	public int size()
	{
		return(t+1);
	}
	
	public boolean isEmpty()
	{
		return (t == -1);
	}
	
	public void push(char e) throws IllegalStateException
	{
		if (size() == data.length) 
		{
			throw new IllegalStateException("Stack is full");
		}
		else
		{
			t++;
			data[t] = e;
		}
	}
	
	@SuppressWarnings("null")
	public char top()
	{
		if (isEmpty())
		{
			return (Character) null;
		}
		else
		{
			return data[t];
		}
	}
	
	@SuppressWarnings("null")
	public char pop()
	{
		if(isEmpty())
		{
			return (Character) null;
		}
		else
		{
			char answer = data[t];
			data[t] = Character.MIN_VALUE;
			t--;
			return  answer;
		}
	}
	
	public int max()
	{
		char current = this.top();
		Stack pushBack = new Stack(data.length);
		while(!isEmpty())
		{
			if (current < this.top())
			{
				current = this.top();
				pushBack.push(this.pop());
			}
			else
			{
				pushBack.push(this.pop());
			}
		}
		while(!pushBack.isEmpty())
		{
			this.push(pushBack.pop());
		}
		return current;
	}
	
	public int max_depth()
	{
		Stack check = new Stack(this.size()+1);
		char current;
		int max = 0;
		while(!this.isEmpty())
		{
			current = this.pop();
			if (current == ')')
			{
				check.push(current);
				if (max == check.size()-1)
				{
					max++;
				}
			}
			else if(current == '(')
			{
				check.pop();
			}
		}
		if (check.size() != 0)
			return -1;
		return max;
	}
	
}

