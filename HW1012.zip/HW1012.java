
public class HW1012
{
	public static void main(String[] args)
	{
		Stack s1 = new Stack(100);
		String str = "(a+c(a+(b+()((()))d)) + (a+c))";
		char[] array = str.toCharArray();
		
		for(int i = 0; i < str.length(); i++)
		{
			s1.push(array[i]);
		}
		
		System.out.println(s1.max_depth());

	}
}
